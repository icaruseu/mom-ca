jsXmlSaxParser
=====

XML SAX Parser in Javascript, almost fully w3c compliant (DTD parsing not totally complete).

Demonstration web page is : http://debeissat.nicolas.free.fr/sax.php
With explanations on the algorithms used.

Initial repository was : https://code.google.com/p/jssaxparser/

