package xquery.sort;

import xquery.TestRunner;

public class SortTests extends TestRunner {

    @Override
    protected String getDirectory() {
        return "extensions/indexes/sort/test/src/xquery/sort";
    }
}