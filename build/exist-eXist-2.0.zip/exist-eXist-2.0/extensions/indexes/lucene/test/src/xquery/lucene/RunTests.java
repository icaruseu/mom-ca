package xquery.lucene;


import xquery.TestRunner;

public class RunTests extends TestRunner {

    @Override
    protected String getDirectory() {
        return "extensions/indexes/lucene/test/src/xquery/lucene";
    }
}
